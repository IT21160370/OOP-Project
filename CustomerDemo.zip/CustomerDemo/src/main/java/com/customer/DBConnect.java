package com.customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBConnect {
	//Create database connection
		private static	String url = "jdbc:mysql://localhost:3306/hotel";
		private static String user = "root";
		private static String pass = "";
		private static Connection conn;
		
		public static Connection getConnection() {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection(url,user,pass);//create connection

			}catch(Exception e) {
				System.out.println("Database Connection is fail");
			}
			return conn;
		}
}




